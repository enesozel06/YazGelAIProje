using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class ObjeYerlestirScript : MonoBehaviour
{
    [SerializeField]private GameObject kup;
    [SerializeField] private GameObject objeYatak;
    [SerializeField] private GameObject objeMasa;
    [SerializeField] private GameObject objedolap;
    [SerializeField] private GameObject objecekmece;
    [SerializeField] private GameObject objebuzDolab�;
    [SerializeField] private GameObject objekap�;


    private DuzlemScript halka;
    void Start()
    {
        halka = FindAnyObjectByType<DuzlemScript>();
        kup.transform.localScale =  new Vector3(0.1f, 0.1f, 0.1f);
        
    }


    public void MasaYerlestir()
    {
        kup = objeMasa;

    }

    public void YatakYerlestir()
    {
        kup = objeYatak;
    }

    public void KapiYerlestir()
    {
        kup = objekap�;
    }

    public void BuzDolapYerlestir()
    {
        kup = objebuzDolab�;

    }

    public void CekmeceYerlestir()
    {
        kup = objecekmece;
    }

    public void DolapYerlestir()
    {
        kup = objedolap;
    }









    void Update()
    {
        if(Input.touchCount>0 && Input.touches[0].phase == TouchPhase.Began)
        {
            GameObject go = Instantiate(kup, halka.transform.position, halka.transform.rotation);
        }
    }
}
