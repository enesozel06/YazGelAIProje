// Simple Side-Menu - https://assetstore.unity.com/packages/tools/gui/simple-side-menu-143623
// Copyright (c) Daniel Lochner

namespace DanielLochner.Assets.SimpleSideMenu
{
    public enum Placement
    {
        Left,
        Right,
        Top,
        Bottom
    }
}