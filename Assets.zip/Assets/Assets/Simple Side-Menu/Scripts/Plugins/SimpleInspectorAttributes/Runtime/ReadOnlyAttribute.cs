﻿using UnityEngine;

namespace DanielLochner.Assets
{
    public class ReadOnlyAttribute : PropertyAttribute
    {

    }
}